package javaapplication4;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
/*
 * In this project propertise the license header need to be chose to change the header.
 * In order to change the tamplate open tools then templates
 * Open the editer to change the template.
 */
  

/**
 *
 * 
 */
public class JavaApplication4 {
    Connection conn=null;
public static Connection ConnecrDb(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn =DriverManager.getConnection("jdbc:mysql://localhost/java_dbmovies","root","");
        return conn;
    }
    //Catch execption
    catch(Exception e)
    {
        System.out.println(e);
    }
    
return null;
}

   
}
